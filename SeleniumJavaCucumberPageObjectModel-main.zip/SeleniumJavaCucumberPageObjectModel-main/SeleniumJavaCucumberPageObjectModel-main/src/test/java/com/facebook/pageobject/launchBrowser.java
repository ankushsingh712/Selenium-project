package com.facebook.pageobject;

public interface launchBrowser {
	
	public void launch();

}
