package com.facebook.utility;

public enum Browser {
CHROME
}
